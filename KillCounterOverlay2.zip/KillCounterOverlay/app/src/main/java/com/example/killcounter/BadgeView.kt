package com.example.killcounter

import android.content.Context
import android.graphics.*
import android.view.View

/** Panel: rasm fon + 4 xonali 7-segmentli raqam. count ni o'zgartirsangiz raqam yangilanadi. */
class BadgeView(c: Context) : View(c) {
    private val bg = BitmapFactory.decodeResource(resources, R.drawable.badge)
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(8f, 0f, 0f, 0xFFA9CCFF.toInt()) }
    private val off = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x262D3036 }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF453A.toInt() }

    /** true bo'lsa (kill kuzatish o'chiq) panel burchagida kichik qizil nuqta ko'rinadi. */
    var capOff = true
        set(v) { field = v; invalidate() }

    private fun path(s: String) = Path().apply {
        s.split(" ").forEachIndexed { i, p ->
            val (x, y) = p.split(",").map { it.toFloat() }
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }
    private val segs = mapOf(
        'a' to path("4,2 66,2 57,12 13,12"), 'f' to path("2,4 12,14 12,47 2,49"),
        'b' to path("68,4 68,49 58,47 58,14"), 'g' to path("11,45 59,45 65,50 59,55 11,55 5,50"),
        'e' to path("2,51 12,53 12,86 2,96"), 'c' to path("68,51 68,96 58,86 58,53"),
        'd' to path("13,88 57,88 66,98 4,98")
    )
    private val digits = arrayOf("abcdef", "bc", "abdeg", "abcdg", "bcfg", "acdfg", "acdefg", "abc", "abcdefg", "abcdfg")

    var count = 0
        set(v) { field = v.coerceIn(0, 9999); invalidate() }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawBitmap(bg, null, RectF(0f, 0f, w, h), bgPaint)
        val px = 0.391f * w; val pw = 0.538f * w; val py = 0.18f * h; val ph = 0.556f * h
        val dw = 0.167f * pw
        val s = minOf(dw / 70f, ph / 100f)
        val str = count.toString().padStart(4, '0')
        for (i in 0..3) {
            val ox = px + i * (pw - dw) / 3f + (dw - 70f * s) / 2f
            val oy = py + (ph - 100f * s) / 2f
            cv.save(); cv.translate(ox, oy); cv.scale(s, s)
            for ((k, p) in segs) cv.drawPath(p, if (digits[str[i] - '0'].contains(k)) on else off)
            cv.restore()
        }
        if (capOff) cv.drawCircle(0.035f * w, 0.88f * h, 0.018f * w, dot)
    }
}
