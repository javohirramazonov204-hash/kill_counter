package com.example.killcounter

import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

class Tpl(val w: Int, val h: Int, val bits: BooleanArray) {
    val xs: IntArray
    val ys: IntArray
    val n: Int
    init {
        val lx = ArrayList<Int>(); val ly = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) if (bits[y * w + x]) { lx.add(x); ly.add(y) }
        xs = lx.toIntArray(); ys = ly.toIntArray(); n = xs.size
    }
}

class Hit(val sig: BooleanArray)

/**
 * Chap tomondagi kill qatorini qidiradi: foydalanuvchi ismi + M416 qurol rasmi.
 * Ism shabloni standart ("я7") yoki "Ismni o'rgatish" orqali o'rganilgan bo'ladi.
 */
class KillDetector(private val ctx: Context) {
    private val icon = parse(ctx.assets.open("icon.txt").bufferedReader().readLines())
    private var nick = parse(ctx.assets.open("nick.txt").bufferedReader().readLines())
    private var iconDx = DEFAULT_DX
    @Volatile var learned = false
    private var pending: Tpl? = null

    companion object {
        const val RY = 220            // qidiruv oynasi: ekran (1080 balandlik) bo'yicha y=220..640, x=0..700
        const val WW = 350            // ish o'lchami (yarim)
        const val WH = 210
        const val ROW_LEFT = 25       // kill qatorining chap chekkasi (ish pikselida)
        const val DEFAULT_DX = 49     // ism shablonidan qurol shablonigacha masofa
        const val NICK_MIN = 0.40f
        const val ICON_MIN = 0.72f
        const val ICON_RECALL = 0.75f
        const val FILE = "nick_custom.txt"
    }

    private val m = BooleanArray(WW * WH)
    private val ii = IntArray((WW + 1) * (WH + 1))

    init { reload() }

    private fun parse(all: List<String>): Tpl {
        val lines = all.filter { it.isNotEmpty() }
        val h = lines.size; val w = lines[0].length
        return Tpl(w, h, BooleanArray(w * h) { lines[it / w][it % w] == '1' })
    }

    /** O'rganilgan ism bo'lsa uni, bo'lmasa standartni yuklaydi. */
    fun reload() {
        val f = File(ctx.filesDir, FILE)
        val dx = ctx.getSharedPreferences("kc", Context.MODE_PRIVATE).getInt("nick_dx", -1)
        if (f.exists() && dx > 0) {
            try { nick = parse(f.readLines()); iconDx = dx; return } catch (t: Throwable) { Dbg.add("Ism fayli o'qilmadi: $t") }
        }
        nick = parse(ctx.assets.open("nick.txt").bufferedReader().readLines()); iconDx = DEFAULT_DX
    }

    private fun cyan(buf: ByteBuffer, i: Int): Boolean {
        val r = buf.get(i).toInt() and 0xFF
        val g = buf.get(i + 1).toInt() and 0xFF
        val b = buf.get(i + 2).toInt() and 0xFF
        return b >= 215 && g >= 200 && r <= 190 && g - r >= 45 && b - r >= 55
    }

    private fun count(u: Int, v: Int, w: Int, h: Int): Int {
        val s = WW + 1
        return ii[(v + h) * s + u + w] - ii[v * s + u + w] - ii[(v + h) * s + u] + ii[v * s + u]
    }

    private fun dice(t: Tpl, u: Int, v: Int): Float {
        val wc = count(u, v, t.w, t.h)
        if (wc < 0.4f * t.n || wc > 3f * t.n) return 0f
        var inter = 0
        for (k in 0 until t.n) if (m[(v + t.ys[k]) * WW + u + t.xs[k]]) inter++
        return 2f * inter / (wc + t.n)
    }

    /** O'rgatish rejimi: M416 qurol rasmi turgan qatorning chap qismini yangi ism shabloni qilib oladi. */
    private fun tryLearn() {
        var best = 0f; var bu = 0; var bv = 0
        for (v in 0..WH - icon.h) for (u in ROW_LEFT + 12..WW - icon.w) {
            val d = dice(icon, u, v)
            if (d > best) { best = d; bu = u; bv = v }
        }
        if (best < 0.80f) { pending = null; return }
        val w = bu - ROW_LEFT - 1
        if (w < 24) { pending = null; return }
        val h = icon.h
        val cand = Tpl(w, h, BooleanArray(w * h) { m[(bv + it / w) * WW + ROW_LEFT + it % w] })
        if (cand.n < 20) { pending = null; return }
        val p = pending
        if (p != null && p.w == w && same(p, cand)) {
            File(ctx.filesDir, FILE).writeText((0 until h).joinToString("\n") { y ->
                (0 until w).joinToString("") { x -> if (cand.bits[y * w + x]) "1" else "0" }
            } + "\n")
            ctx.getSharedPreferences("kc", Context.MODE_PRIVATE).edit().putInt("nick_dx", bu - ROW_LEFT).apply()
            nick = cand; iconDx = bu - ROW_LEFT; learned = true; pending = null
            Dbg.add("Yangi ism o'rganildi (${cand.n} nuqta)")
        } else pending = cand
    }

    private fun same(a: Tpl, b: Tpl): Boolean {
        var i = 0
        for (k in a.bits.indices) if (a.bits[k] && b.bits[k]) i++
        return 2f * i / (a.n + b.n) >= 0.9f
    }

    fun process(buf: ByteBuffer, rowStride: Int, pixStride: Int, imgW: Int, imgH: Int, f: Float, teach: Boolean = false): List<Hit> {
        val offs = floatArrayOf(0.5f, 1.5f)
        var total = 0
        for (v in 0 until WH) for (u in 0 until WW) {
            var c = 0
            for (sy in offs) for (sx in offs) {
                val x = ((u * 2 + sx) * f).toInt()
                val y = ((RY + v * 2 + sy) * f).toInt()
                if (x < imgW && y < imgH && cyan(buf, y * rowStride + x * pixStride)) c++
            }
            val b = c >= 2
            m[v * WW + u] = b
            if (b) total++
        }
        if (total < 40) return emptyList()

        val s = WW + 1
        for (y in 0 until WH) {
            var run = 0
            for (x in 0 until WW) {
                if (m[y * WW + x]) run++
                ii[(y + 1) * s + x + 1] = ii[y * s + x + 1] + run
            }
        }
        if (teach) { tryLearn(); return emptyList() }

        // 1) foydalanuvchi ismini qidirish
        val nk = nick
        val cands = ArrayList<FloatArray>() // score, u, v
        for (v in 0..WH - nk.h) for (u in 0..WW - nk.w) {
            val d = dice(nk, u, v)
            if (d >= NICK_MIN) cands.add(floatArrayOf(d, u.toFloat(), v.toFloat()))
        }
        cands.sortByDescending { it[0] }
        val kept = ArrayList<FloatArray>()
        for (c in cands) if (kept.none { Math.abs(it[2] - c[2]) < 14f }) kept.add(c)

        // 2) har bir qatorda qurol rasmini tekshirish
        val hits = ArrayList<Hit>()
        for (c in kept) {
            val u = c[1].toInt(); val v = c[2].toInt()
            var best = 0f; var bu = 0; var bv = 0
            for (dy in -1..1) for (dx in -2..2) {
                val iu = u + iconDx + dx; val iv = v + dy
                if (iu < 0 || iv < 0 || iu + icon.w > WW || iv + icon.h > WH) continue
                val d = dice(icon, iu, iv)
                if (d > best) { best = d; bu = iu; bv = iv }
            }
            var inter = 0
            if (best > 0f) for (k in 0 until icon.n) if (m[(bv + icon.ys[k]) * WW + bu + icon.xs[k]]) inter++
            val recall = inter.toFloat() / icon.n
            val ok = best >= ICON_MIN && recall >= ICON_RECALL
            if (best >= 0.35f) {
                val msg = "nick=%.2f icon=%.2f rec=%.2f %s".format(c[0], best, recall, if (ok) "OK" else "RAD")
                Log.d("KC", msg); Dbg.add(msg)
            }
            if (!ok) continue
            // raqib ismi (qurol rasmidan o'ngda) — bir killni qayta sanamaslik uchun belgi
            val sig = BooleanArray(25 * 5)
            val x0 = bu + icon.w
            for (yy in 0 until icon.h) for (xx in 0 until 125) {
                val px = x0 + xx; val py = bv + yy
                if (px < WW && py < WH && m[py * WW + px]) sig[(yy * 5 / icon.h) * 25 + xx / 5] = true
            }
            hits.add(Hit(sig))
        }
        return hits
    }
}
