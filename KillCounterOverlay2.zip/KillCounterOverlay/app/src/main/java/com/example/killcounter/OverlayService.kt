package com.example.killcounter

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*

/** PUBG (va boshqa ilovalar) ustida suzib turadigan panel. Ikki barmoq bilan hajmini o'zgartirish mumkin. */
class OverlayService : Service() {
    companion object {
        @Volatile private var inst: OverlayService? = null
        private val main = Handler(Looper.getMainLooper())
        fun setCount(n: Int) { main.post { inst?.setCountInternal(n) } }
        fun addKill() { main.post { inst?.let { it.setCountInternal((it.view?.count ?: 0) + 1) } } }
        fun setCapture(on: Boolean) { main.post { inst?.view?.capOff = !on } }
        fun setSize(ctx: Context, pct: Int) {
            ctx.getSharedPreferences("kc", Context.MODE_PRIVATE).edit().putInt("size", pct).apply()
            main.post { inst?.applySize(pct.toFloat()) }
        }
        fun setAlpha(ctx: Context, pct: Int) {
            ctx.getSharedPreferences("kc", Context.MODE_PRIVATE).edit().putInt("alpha", pct).apply()
            main.post { inst?.view?.alpha = pct / 100f }
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private var view: BadgeView? = null
    private var sizeF = 100f

    override fun onBind(i: Intent?): IBinder? = null

    private fun setCountInternal(n: Int) {
        view?.let { it.count = n; sp.edit().putInt("m416", it.count).apply() }
    }

    private fun applySize(p: Float) {
        sizeF = p.coerceIn(30f, 250f)
        val w = (280 * resources.displayMetrics.density * sizeF / 100f).toInt()
        lp.width = w; lp.height = w * 387 / 1561
        view?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, lp) }
        sp.edit().putInt("size", sizeF.toInt()).apply()
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kc", "Kill counter", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "kc").setContentTitle("Kill counter yoqilgan")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("kc", MODE_PRIVATE)
        val v = BadgeView(this); view = v
        v.count = sp.getInt("m416", 0)
        v.alpha = sp.getInt("alpha", 100) / 100f
        v.capOff = !Dbg.capture
        sizeF = sp.getInt("size", 100).toFloat()
        val wpx = (280 * resources.displayMetrics.density * sizeF / 100f).toInt()
        lp = WindowManager.LayoutParams(
            wpx, wpx * 387 / 1561, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt("x", (resources.displayMetrics.widthPixels * 0.52f).toInt())  // chap kill qatoridan uzoqroq
            y = sp.getInt("y", 0)
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var rebase = true
        val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { applySize(sizeF * d.scaleFactor); return true }
        })
        v.setOnTouchListener { _, e ->
            sgd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; rebase = false }
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> rebase = true
                MotionEvent.ACTION_MOVE -> if (!sgd.isInProgress && e.pointerCount == 1) {
                    if (rebase) { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; rebase = false }
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> sp.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            true
        }
        wm.addView(v, lp)
        inst = this
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        inst = null
        view?.let { wm.removeView(it) }; view = null
        super.onDestroy()
    }
}
