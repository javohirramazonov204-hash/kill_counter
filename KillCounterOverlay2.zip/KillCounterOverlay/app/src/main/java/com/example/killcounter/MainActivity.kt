package com.example.killcounter

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val REQ = 7
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("kc", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        fun label(t: String) = root.addView(TextView(this).apply { text = t; setPadding(0, 32, 0, 0) })
        fun seek(max: Int, start: Int, onChange: (Int) -> Unit) = root.addView(SeekBar(this).apply {
            this.max = max; progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        btn("1. Panelni yoqish") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        btn("2. Kill sanashni boshlash") {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        }
        btn("To'xtatish") {
            stopService(Intent(this, CaptureService::class.java))
            stopService(Intent(this, OverlayService::class.java))
        }
        btn("Nolga qaytarish") {
            sp.edit().putInt("m416", 0).apply()
            OverlayService.setCount(0)
        }
        btn("+1 (sinov)") { OverlayService.addKill() }

        label("Foydalanuvchi ismi")
        btn("Ismni o'rgatish (M416 bilan kill qiling)") {
            if (!Dbg.capture) {
                Toast.makeText(this, "Avval 2-tugma bilan kuzatishni yoqing", Toast.LENGTH_LONG).show()
            } else {
                CaptureService.teach(45)
                Toast.makeText(this, "45 soniya ichida PUBG'da M416 bilan kill qiling", Toast.LENGTH_LONG).show()
            }
        }
        btn("Standart ismga qaytarish (я7)") {
            File(filesDir, "nick_custom.txt").delete()
            sp.edit().remove("nick_dx").apply()
            CaptureService.requestReload()
            Toast.makeText(this, "Standart ism (я7) tiklandi", Toast.LENGTH_SHORT).show()
        }

        label("Panel hajmi (panelni ikki barmoq bilan ham kattalashtirish mumkin)")
        seek(220, sp.getInt("size", 100) - 30) { OverlayService.setSize(this, it + 30) }
        label("Panel shaffofligi")
        seek(80, sp.getInt("alpha", 100) - 20) { OverlayService.setAlpha(this, it + 20) }

        info = TextView(this).apply { textSize = 12f; setPadding(0, 48, 0, 0) }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private val tick = object : Runnable { override fun run() { refresh(); ui.postDelayed(this, 1000) } }
    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun refresh() {
        val ago = if (Dbg.lastFrame == 0L) "-" else "${(SystemClock.elapsedRealtime() - Dbg.lastFrame) / 1000}s"
        val custom = File(filesDir, "nick_custom.txt").exists() && getSharedPreferences("kc", MODE_PRIVATE).getInt("nick_dx", -1) > 0
        info.text = "Ism: ${if (custom) "o'rgatilgan" else "standart (я7)"}\nKuzatish: ${if (Dbg.capture) "yoniq" else "o'chiq"}\n" +
            "Kadrlar: ${Dbg.frames} (oxirgisi $ago oldin)\nSanalgan: ${Dbg.kills}\n" +
            (if (Dbg.error.isEmpty()) "" else "Xato: ${Dbg.error}\n") +
            "--- so'nggi voqealar ---\n${Dbg.text()}"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == REQ && c == RESULT_OK && d != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", c).putExtra("data", d))
        }
    }
}
