package com.example.killcounter

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tekshiruv uchun: kuzatish holati va so'nggi voqealar (ilovaning bosh ekranida ko'rinadi). */
object Dbg {
    @Volatile var frames = 0L
    @Volatile var lastFrame = 0L
    @Volatile var kills = 0
    @Volatile var capture = false
    @Volatile var error = ""
    private val log = ArrayDeque<String>()
    private var lastMsg = ""

    @Synchronized fun add(msg: String) {
        if (msg == lastMsg) return
        lastMsg = msg
        log.addFirst(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + " " + msg)
        while (log.size > 25) log.removeLast()
    }

    @Synchronized fun text(): String = log.joinToString("\n")
}
