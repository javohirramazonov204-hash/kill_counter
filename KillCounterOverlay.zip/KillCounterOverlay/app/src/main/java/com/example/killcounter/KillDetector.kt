package com.example.killcounter

import android.content.Context
import android.util.Log
import java.nio.ByteBuffer

class Tpl(val w: Int, val h: Int, bits: BooleanArray) {
    val xs: IntArray
    val ys: IntArray
    val n: Int
    init {
        val lx = ArrayList<Int>(); val ly = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) if (bits[y * w + x]) { lx.add(x); ly.add(y) }
        xs = lx.toIntArray(); ys = ly.toIntArray(); n = xs.size
    }
}

class Hit(val sig: BooleanArray)

/**
 * Chap tomondagi kill qatorini qidiradi: "я7" ismi + M416 qurol rasmi.
 * Rasm 1080 balandlikdagi ekranga nisbatan olingan (shablonlar assets/ da).
 */
class KillDetector(ctx: Context) {
    private val nick = load(ctx, "nick.txt")
    private val icon = load(ctx, "icon.txt")

    companion object {
        const val RY = 220            // qidiruv oynasi: ekran (1080 balandlik) bo'yicha y=220..640, x=0..700
        const val WW = 350            // ish o'lchami (yarim)
        const val WH = 210
        const val ICON_DX = 49        // ism shablonidan qurol shablonigacha masofa
        const val NICK_MIN = 0.40f
        const val ICON_MIN = 0.60f
    }

    private val m = BooleanArray(WW * WH)
    private val ii = IntArray((WW + 1) * (WH + 1))

    private fun load(ctx: Context, name: String): Tpl {
        val lines = ctx.assets.open(name).bufferedReader().readLines().filter { it.isNotEmpty() }
        val h = lines.size; val w = lines[0].length
        return Tpl(w, h, BooleanArray(w * h) { lines[it / w][it % w] == '1' })
    }

    private fun cyan(buf: ByteBuffer, i: Int): Boolean {
        val r = buf.get(i).toInt() and 0xFF
        val g = buf.get(i + 1).toInt() and 0xFF
        val b = buf.get(i + 2).toInt() and 0xFF
        return b >= 215 && g >= 200 && r <= 190 && g - r >= 45 && b - r >= 55
    }

    private fun count(u: Int, v: Int, w: Int, h: Int): Int {
        val s = WW + 1
        return ii[(v + h) * s + u + w] - ii[v * s + u + w] - ii[(v + h) * s + u] + ii[v * s + u]
    }

    private fun dice(t: Tpl, u: Int, v: Int): Float {
        val wc = count(u, v, t.w, t.h)
        if (wc < 0.4f * t.n || wc > 3f * t.n) return 0f
        var inter = 0
        for (k in 0 until t.n) if (m[(v + t.ys[k]) * WW + u + t.xs[k]]) inter++
        return 2f * inter / (wc + t.n)
    }

    fun process(buf: ByteBuffer, rowStride: Int, pixStride: Int, imgW: Int, imgH: Int, f: Float): List<Hit> {
        val offs = floatArrayOf(0.5f, 1.5f)
        var total = 0
        for (v in 0 until WH) for (u in 0 until WW) {
            var c = 0
            for (sy in offs) for (sx in offs) {
                val x = ((u * 2 + sx) * f).toInt()
                val y = ((RY + v * 2 + sy) * f).toInt()
                if (x < imgW && y < imgH && cyan(buf, y * rowStride + x * pixStride)) c++
            }
            val b = c >= 2
            m[v * WW + u] = b
            if (b) total++
        }
        if (total < 40) return emptyList()

        val s = WW + 1
        for (y in 0 until WH) {
            var run = 0
            for (x in 0 until WW) {
                if (m[y * WW + x]) run++
                ii[(y + 1) * s + x + 1] = ii[y * s + x + 1] + run
            }
        }

        // 1) "я7" ismini qidirish
        val cands = ArrayList<FloatArray>() // score, u, v
        for (v in 0..WH - nick.h) for (u in 0..WW - nick.w) {
            val d = dice(nick, u, v)
            if (d >= NICK_MIN) cands.add(floatArrayOf(d, u.toFloat(), v.toFloat()))
        }
        cands.sortByDescending { it[0] }
        val kept = ArrayList<FloatArray>()
        for (c in cands) if (kept.none { Math.abs(it[2] - c[2]) < 14f }) kept.add(c)

        // 2) har bir qatorda qurol rasmini tekshirish
        val hits = ArrayList<Hit>()
        for (c in kept) {
            val u = c[1].toInt(); val v = c[2].toInt()
            var best = 0f; var bu = 0; var bv = 0
            for (dy in -2..2) for (dx in -3..3) {
                val iu = u + ICON_DX + dx; val iv = v + dy
                if (iu < 0 || iv < 0 || iu + icon.w > WW || iv + icon.h > WH) continue
                val d = dice(icon, iu, iv)
                if (d > best) { best = d; bu = iu; bv = iv }
            }
            Log.d("KC", "nick=%.2f icon=%.2f".format(c[0], best))
            if (best < ICON_MIN) continue
            // raqib ismi (qurol rasmidan o'ngda) — bir killni qayta sanamaslik uchun belgi
            val sig = BooleanArray(25 * 5)
            val x0 = bu + icon.w
            for (yy in 0 until icon.h) for (xx in 0 until 125) {
                val px = x0 + xx; val py = bv + yy
                if (px < WW && py < WH && m[py * WW + px]) sig[(yy * 5 / icon.h) * 25 + xx / 5] = true
            }
            hits.add(Hit(sig))
        }
        return hits
    }
}
