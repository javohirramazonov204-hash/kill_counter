package com.example.killcounter

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*

/** PUBG (va boshqa ilovalar) ustida suzib turadigan panel. */
class OverlayService : Service() {
    companion object {
        @Volatile private var view: BadgeView? = null
        @Volatile private var prefs: SharedPreferences? = null
        private val main = Handler(Looper.getMainLooper())
        fun setCount(n: Int) { main.post { view?.let { it.count = n; prefs?.edit()?.putInt("m416", it.count)?.apply() } } }
        fun addKill() { main.post { view?.let { it.count = it.count + 1; prefs?.edit()?.putInt("m416", it.count)?.apply() } } }
    }

    private lateinit var wm: WindowManager
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kc", "Kill counter", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "kc").setContentTitle("Kill counter yoqilgan")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val sp = getSharedPreferences("kc", MODE_PRIVATE); prefs = sp
        val v = BadgeView(this); view = v
        v.count = sp.getInt("m416", 0)
        val wpx = (280 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            wpx, wpx * 387 / 1561, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt("x", (resources.displayMetrics.widthPixels * 0.52f).toInt())  // chap kill qatoridan uzoqroq
            y = sp.getInt("y", 0)
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(v, lp) }
                MotionEvent.ACTION_UP -> sp.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            true
        }
        wm.addView(v, lp)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        view?.let { wm.removeView(it) }; view = null
        super.onDestroy()
    }
}
