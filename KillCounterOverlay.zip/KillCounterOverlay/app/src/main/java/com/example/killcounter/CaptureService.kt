package com.example.killcounter

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.WindowManager

/** Ekranni kuzatadi, chapdagi kill qatorida "я7 + M416" topsa panelni +1 qiladi. */
class CaptureService : Service() {
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private lateinit var det: KillDetector
    private var last = 0L
    private var prev: List<BooleanArray> = emptyList()
    private val fired = ArrayList<Pair<Long, BooleanArray>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (proj != null) return START_NOT_STICKY
        val code = i?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kc", "Kill counter", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "kc").setContentTitle("Kill sanash yoqilgan")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        det = KillDetector(this)
        val th = HandlerThread("kc-capture"); th.start(); thread = th
        val h = Handler(th.looper)
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        proj = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)

        val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val w = maxOf(b.width(), b.height()); val hh = minOf(b.width(), b.height())
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay("kc", w, hh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage()
            if (img != null) try { handle(img, w, hh) } finally { img.close() }
        }, h)
        return START_NOT_STICKY
    }

    private fun sim(a: BooleanArray, b: BooleanArray): Float {
        var i = 0; var u = 0
        for (k in a.indices) { if (a[k] && b[k]) i++; if (a[k] || b[k]) u++ }
        return if (u == 0) 1f else i.toFloat() / u
    }

    private fun handle(img: Image, w: Int, h: Int) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 200) return
        last = now
        val pl = img.planes[0]
        val hits = det.process(pl.buffer, pl.rowStride, pl.pixelStride, w, h, h / 1080f)
        fired.removeAll { now - it.first > 10000 }
        for (hit in hits) {
            val seenBefore = prev.any { sim(it, hit.sig) >= 0.5f }   // ketma-ket 2 kadrda ko'ringan
            val already = fired.any { sim(it.second, hit.sig) >= 0.5f } // shu killni allaqachon sanaganmiz
            if (seenBefore && !already) { fired.add(now to hit.sig); OverlayService.addKill() }
        }
        prev = hits.map { it.sig }
    }

    override fun onDestroy() {
        vd?.release(); reader?.close(); proj?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}
