package com.example.killcounter

import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

class Tpl(val w: Int, val h: Int, val bits: BooleanArray) {
    val xs: IntArray
    val ys: IntArray
    val n: Int
    init {
        val lx = ArrayList<Int>(); val ly = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) if (bits[y * w + x]) { lx.add(x); ly.add(y) }
        xs = lx.toIntArray(); ys = ly.toIntArray(); n = xs.size
    }
}

class Hit(val sig: BooleanArray)

/** Bir xil kill qatorining bitta o'lchamdagi (HUD masshtabidagi) shabloni. */
class Profile(var nick: Tpl, val icon: Tpl, var dx: Int, val rowLeft: Int)

/**
 * Chap tomondagi kill qatorini qidiradi: foydalanuvchi ismi + M416 qurol rasmi.
 * Ikki xil HUD o'lchami uchun ikkita profil bor. Ism shabloni standart ("я7")
 * yoki "Ismni o'rgatish" orqali o'rganilgan bo'ladi.
 */
class KillDetector(private val ctx: Context) {
    private fun asset(name: String) = parse(ctx.assets.open(name).bufferedReader().readLines())

    private val profiles = listOf(
        Profile(asset("nick.txt"), asset("icon.txt"), 49, 25),     // katta qator
        Profile(asset("nick_s.txt"), asset("icon_s.txt"), 40, 49)  // kichik qator
    )
    private val defNicks = profiles.map { it.nick }
    private val defDx = profiles.map { it.dx }
    @Volatile var learned = false
    private var pending: Tpl? = null
    private var pendingProf = -1

    companion object {
        const val RY = 220            // qidiruv oynasi: ekran (1080 balandlik) bo'yicha y=220..640, x=0..700
        const val WW = 350            // ish o'lchami (yarim)
        const val WH = 210
        const val NICK_MIN = 0.40f
        const val ICON_MIN = 0.72f
        const val ICON_RECALL = 0.75f
        const val FILE = "nick_custom.txt"
    }

    private val m = BooleanArray(WW * WH)
    private val ii = IntArray((WW + 1) * (WH + 1))

    init { reload() }

    private fun parse(all: List<String>): Tpl {
        val lines = all.filter { it.isNotEmpty() }
        val h = lines.size; val w = lines[0].length
        return Tpl(w, h, BooleanArray(w * h) { lines[it / w][it % w] == '1' })
    }

    /** O'rganilgan ism bo'lsa uni, bo'lmasa standartni yuklaydi. */
    fun reload() {
        for (i in profiles.indices) { profiles[i].nick = defNicks[i]; profiles[i].dx = defDx[i] }
        val sp = ctx.getSharedPreferences("kc", Context.MODE_PRIVATE)
        val f = File(ctx.filesDir, FILE)
        val dx = sp.getInt("nick_dx", -1)
        val pi = sp.getInt("nick_prof", 0)
        if (f.exists() && dx > 0 && pi in profiles.indices) {
            try { profiles[pi].nick = parse(f.readLines()); profiles[pi].dx = dx }
            catch (t: Throwable) { Dbg.add("Ism fayli o'qilmadi: $t") }
        }
    }

    private fun cyan(buf: ByteBuffer, i: Int): Boolean {
        val r = buf.get(i).toInt() and 0xFF
        val g = buf.get(i + 1).toInt() and 0xFF
        val b = buf.get(i + 2).toInt() and 0xFF
        return b >= 215 && g >= 200 && r <= 190 && g - r >= 45 && b - r >= 55
    }

    private fun count(u: Int, v: Int, w: Int, h: Int): Int {
        val s = WW + 1
        return ii[(v + h) * s + u + w] - ii[v * s + u + w] - ii[(v + h) * s + u] + ii[v * s + u]
    }

    private fun dice(t: Tpl, u: Int, v: Int): Float {
        val wc = count(u, v, t.w, t.h)
        if (wc < 0.4f * t.n || wc > 3f * t.n) return 0f
        var inter = 0
        for (k in 0 until t.n) if (m[(v + t.ys[k]) * WW + u + t.xs[k]]) inter++
        return 2f * inter / (wc + t.n)
    }

    /** O'rgatish rejimi: M416 qurol rasmi turgan qatorning chap qismini yangi ism shabloni qilib oladi. */
    private fun tryLearn() {
        var best = 0f; var bu = 0; var bv = 0; var bp = -1
        for ((pi, p) in profiles.withIndex()) {
            for (v in 0..WH - p.icon.h) for (u in p.rowLeft + 12..WW - p.icon.w) {
                val d = dice(p.icon, u, v)
                if (d > best) { best = d; bu = u; bv = v; bp = pi }
            }
        }
        if (bp < 0 || best < 0.80f) { pending = null; return }
        val p = profiles[bp]
        val w = bu - p.rowLeft - 1
        if (w < 24) { pending = null; return }
        val h = p.icon.h
        val cand = Tpl(w, h, BooleanArray(w * h) { m[(bv + it / w) * WW + p.rowLeft + it % w] })
        if (cand.n < 12) { pending = null; return }
        val old = pending
        if (old != null && pendingProf == bp && old.w == w && same(old, cand)) {
            File(ctx.filesDir, FILE).writeText((0 until h).joinToString("\n") { y ->
                (0 until w).joinToString("") { x -> if (cand.bits[y * w + x]) "1" else "0" }
            } + "\n")
            ctx.getSharedPreferences("kc", Context.MODE_PRIVATE).edit()
                .putInt("nick_dx", bu - p.rowLeft).putInt("nick_prof", bp).apply()
            p.nick = cand; p.dx = bu - p.rowLeft; learned = true; pending = null
            Dbg.add("Yangi ism o'rganildi (${cand.n} nuqta)")
        } else { pending = cand; pendingProf = bp }
    }

    private fun same(a: Tpl, b: Tpl): Boolean {
        var i = 0
        for (k in a.bits.indices) if (a.bits[k] && b.bits[k]) i++
        return 2f * i / (a.n + b.n) >= 0.9f
    }

    fun process(buf: ByteBuffer, rowStride: Int, pixStride: Int, imgW: Int, imgH: Int, f: Float, teach: Boolean = false): List<Hit> {
        val offs = floatArrayOf(0.5f, 1.5f)
        var total = 0
        for (v in 0 until WH) for (u in 0 until WW) {
            var c = 0
            for (sy in offs) for (sx in offs) {
                val x = ((u * 2 + sx) * f).toInt()
                val y = ((RY + v * 2 + sy) * f).toInt()
                if (x < imgW && y < imgH && cyan(buf, y * rowStride + x * pixStride)) c++
            }
            val b = c >= 2
            m[v * WW + u] = b
            if (b) total++
        }
        if (total < 40) return emptyList()

        val s = WW + 1
        for (y in 0 until WH) {
            var run = 0
            for (x in 0 until WW) {
                if (m[y * WW + x]) run++
                ii[(y + 1) * s + x + 1] = ii[y * s + x + 1] + run
            }
        }
        if (teach) { tryLearn(); return emptyList() }

        val hits = ArrayList<Hit>()
        for ((pi, p) in profiles.withIndex()) {
            val nk = p.nick; val icon = p.icon

            // 1) foydalanuvchi ismini qidirish
            val cands = ArrayList<FloatArray>() // score, u, v
            for (v in 0..WH - nk.h) for (u in 0..WW - nk.w) {
                val d = dice(nk, u, v)
                if (d >= NICK_MIN) cands.add(floatArrayOf(d, u.toFloat(), v.toFloat()))
            }
            cands.sortByDescending { it[0] }
            val kept = ArrayList<FloatArray>()
            for (c in cands) if (kept.none { Math.abs(it[2] - c[2]) < 14f }) kept.add(c)

            // 2) har bir qatorda qurol rasmini tekshirish
            for (c in kept) {
                val u = c[1].toInt(); val v = c[2].toInt()
                var best = 0f; var bu = 0; var bv = 0
                for (dy in -1..1) for (dx in -2..2) {
                    val iu = u + p.dx + dx; val iv = v + dy
                    if (iu < 0 || iv < 0 || iu + icon.w > WW || iv + icon.h > WH) continue
                    val d = dice(icon, iu, iv)
                    if (d > best) { best = d; bu = iu; bv = iv }
                }
                var inter = 0
                if (best > 0f) for (k in 0 until icon.n) if (m[(bv + icon.ys[k]) * WW + bu + icon.xs[k]]) inter++
                val recall = inter.toFloat() / icon.n
                val ok = best >= ICON_MIN && recall >= ICON_RECALL
                if (best >= 0.35f) {
                    val msg = "p%d nick=%.2f icon=%.2f rec=%.2f %s".format(pi, c[0], best, recall, if (ok) "OK" else "RAD")
                    Log.d("KC", msg); Dbg.add(msg)
                }
                if (!ok) continue
                // raqib ismi (qurol rasmidan o'ngda) — bir killni qayta sanamaslik uchun belgi
                val sig = BooleanArray(25 * 5)
                val x0 = bu + icon.w
                for (yy in 0 until icon.h) for (xx in 0 until 125) {
                    val px = x0 + xx; val py = bv + yy
                    if (px < WW && py < WH && m[py * WW + px]) sig[(yy * 5 / icon.h) * 25 + xx / 5] = true
                }
                hits.add(Hit(sig))
            }
        }
        return hits
    }
}
